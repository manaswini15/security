<html>
    <body>
        <?php
            print "Not found: " . urldecode($_SERVER["REQUEST_URI"]); 
        ?>
    </body>
</html>
