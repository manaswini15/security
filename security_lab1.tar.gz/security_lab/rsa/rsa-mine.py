def checkprime(num):
	for i in range(2,num):
		if(num%i == 0):
			raise "Not prime"
	return True 


def gcd(a,b):
	while(b):
		a,b = b,a%b 
	return a

		
def findE(n,totient):
	for i in range(totient-1,1,-1):
		ans=gcd(i,totient)		
		print("checking..",i,ans)
		if(ans==1):
			return i

	
def publicKey():
	p=int(input("Enter two prime numbers"))
	q=int(input())
	
	if checkprime(p) and checkprime(q):
		n=p*q;
		totient=(p-1)*(q-1)
		e=findE(n,totient)

		return n,e,totient


def encrypt(n,e,text):
	cipher=[]
	for ch in text:
		val=ord(ch)-97
		val=(val**e)%n
		cipher.append(val)
	return cipher	

def privateKey(e,totient):		
	i=1
	while(1):
		print(e,i,e*i,totient)
		if((e*i)%totient == 1):
			return i
		i=i+1	

def decrypt(d,cipher,n):
	s=""
	for c in cipher:			
		s=s+str(chr(((c**d) % n )+97))
	return s
		
text=input("Enter text\n")
n,e,totient=publicKey();
print(n,e,totient)
cipher=encrypt(n,e,text)
print(cipher)
d=privateKey(e,totient)
print(d)
pt=decrypt(d,cipher,n)
print(pt)
