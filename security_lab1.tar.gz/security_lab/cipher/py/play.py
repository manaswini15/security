from pycipher import Playfair
print(Playfair('zgptfoihmuwdrcnykeqaxvsbl').encipher('defend the east wall of the castle'))
print(Playfair('zgptfoihmuwdrcnykeqaxvsbl').decipher('RKPAWRPMYSELZCLFXUZFRSNQBPSA'))


print(Playfair('INSTRUMENTSZ').encipher('ACT'))
print(Playfair('MONARCHY').decipher('POH'))
